// Function to clear all form information
function clearForm(form) {
    form.username.value = "";
    form.password.value = "";

    // Uncheck all radio buttons and checkboxes
    form.querySelectorAll(
        'input[type="radio"], input[type="checkbox"]'
    ).forEach(function(el) {
        el.checked = false;
    });

    // Select the first city option
    form.city.selectedIndex = 0;
}