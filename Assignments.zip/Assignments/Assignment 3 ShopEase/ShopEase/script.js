"use strict";
const CATEGORIES = [
  { name: "Electronics", img: "images/cat-electronics.png" },
  { name: "Clothing", img: "images/cat-clothing.png" },
  { name: "Shoes", img: "images/cat-shoes.png" },
  { name: "Accessories", img: "images/cat-accessories.png" },
  { name: "Home Appliances", img: "images/cat-appliances.png" },
];

const PRODUCTS = [
  { id: 1, name: "Wireless Headphones", category: "Electronics", brand: "SoundMax", price: 59.99, oldPrice: 79.99, rating: 4.5, img: "images/headphones.png", tags: ["featured", "best", "offer"], desc: "Over-ear Bluetooth headphones with deep bass, active noise reduction and up to 30 hours of battery life. Foldable design with a soft memory-foam headband." },
  { id: 2, name: "Smartphone X12", category: "Electronics", brand: "TechNova", price: 399, rating: 4.3, img: "images/smartphone.png", tags: ["featured", "new"], desc: "6.5-inch AMOLED display, 128 GB storage, 50 MP dual camera and a 5000 mAh battery with fast charging. Smooth performance for work and play." },
  { id: 3, name: "Laptop Pro 15", category: "Electronics", brand: "TechNova", price: 799, rating: 4.7, img: "images/laptop.png", tags: ["featured", "best"], desc: "15.6-inch Full HD laptop with a fast multi-core processor, 16 GB RAM and 512 GB SSD. Slim, lightweight and perfect for students and professionals." },
  { id: 4, name: "Smart Watch Fit", category: "Electronics", brand: "SoundMax", price: 129.99, oldPrice: 159.99, rating: 4.2, img: "images/smartwatch.png", tags: ["new", "offer"], desc: "Fitness smart watch with heart-rate monitor, sleep tracking, GPS and call notifications. Water resistant with a 7-day battery." },
  { id: 5, name: "Cotton T-Shirt", category: "Clothing", brand: "StyleHub", price: 19.99, rating: 4.1, img: "images/tshirt.png", tags: ["best", "new"], desc: "Soft 100% cotton crew-neck t-shirt with a relaxed fit. Breathable, durable and easy to style for everyday wear." },
  { id: 6, name: "Denim Jacket", category: "Clothing", brand: "Urbano", price: 69.99, oldPrice: 89.99, rating: 4.4, img: "images/denim-jacket.png", tags: ["featured", "offer"], desc: "Classic denim jacket with a modern cut, button front and two chest pockets. A timeless layer for every season." },
  { id: 7, name: "Slim Fit Jeans", category: "Clothing", brand: "Urbano", price: 44.99, rating: 4.0, img: "images/jeans.png", tags: ["best"], desc: "Stretch-denim slim fit jeans that stay comfortable all day. Fade-resistant color with reinforced stitching." },
  { id: 8, name: "Pullover Hoodie", category: "Clothing", brand: "StyleHub", price: 39.99, rating: 4.6, img: "images/hoodie.png", tags: ["new", "best"], desc: "Cozy fleece-lined hoodie with an adjustable hood and kangaroo pocket. Warm, soft and ready for chilly days." },
  { id: 9, name: "Running Sneakers", category: "Shoes", brand: "StepUp", price: 74.99, rating: 4.6, img: "images/sneakers.png", tags: ["featured", "best"], desc: "Lightweight breathable running sneakers with a cushioned sole and strong grip. Designed for comfort on long runs and daily walks." },
  { id: 10, name: "Leather Boots", category: "Shoes", brand: "StepUp", price: 109.99, oldPrice: 139.99, rating: 4.5, img: "images/boots.png", tags: ["offer"], desc: "Genuine leather boots with a durable rubber sole and padded collar. Built to handle city streets and weekend trails." },
  { id: 11, name: "Sports Shoes", category: "Shoes", brand: "StepUp", price: 64.99, rating: 4.2, img: "images/sports-shoes.png", tags: ["new"], desc: "All-round training shoes with a flexible midsole and supportive fit. Perfect for the gym, court or track." },
  { id: 12, name: "Formal Loafers", category: "Shoes", brand: "Urbano", price: 84.99, rating: 3.9, img: "images/loafers.png", tags: [], desc: "Polished slip-on loafers with a cushioned insole. A smart choice for office, meetings and special occasions." },
  { id: 13, name: "Travel Backpack", category: "Accessories", brand: "Urbano", price: 49.99, rating: 4.4, img: "images/backpack.png", tags: ["featured", "best"], desc: "Spacious water-resistant backpack with a padded laptop compartment, multiple pockets and comfortable adjustable straps." },
  { id: 14, name: "Sunglasses", category: "Accessories", brand: "StyleHub", price: 24.99, oldPrice: 34.99, rating: 4.0, img: "images/sunglasses.png", tags: ["new", "offer"], desc: "UV400 protective sunglasses with a lightweight frame and scratch-resistant lenses. Stylish protection for sunny days." },
  { id: 15, name: "Leather Wallet", category: "Accessories", brand: "Urbano", price: 29.99, rating: 4.3, img: "images/wallet.png", tags: [], desc: "Slim bi-fold wallet made of soft leather with card slots, a coin pocket and RFID protection." },
  { id: 16, name: "Classic Wrist Watch", category: "Accessories", brand: "StyleHub", price: 89.99, rating: 4.5, img: "images/wrist-watch.png", tags: ["featured"], desc: "Elegant analog wrist watch with a stainless-steel case, scratch-resistant glass and a comfortable strap." },
  { id: 17, name: "Power Blender", category: "Home Appliances", brand: "HomePro", price: 54.99, oldPrice: 69.99, rating: 4.3, img: "images/blender.png", tags: ["best", "offer"], desc: "600 W blender with a 1.5 L jar and stainless-steel blades. Perfect for smoothies, soups and sauces." },
  { id: 18, name: "Microwave Oven", category: "Home Appliances", brand: "HomePro", price: 149.99, rating: 4.1, img: "images/microwave.png", tags: [], desc: "25 L digital microwave with 10 power levels, auto-cook menus and a child safety lock." },
  { id: 19, name: "Air Fryer", category: "Home Appliances", brand: "HomePro", price: 99.99, oldPrice: 129.99, rating: 4.7, img: "images/air-fryer.png", tags: ["new", "best", "offer"], desc: "4 L air fryer that cooks crispy meals with up to 90% less oil. Adjustable temperature, timer and a non-stick basket." },
  { id: 20, name: "Table Fan", category: "Home Appliances", brand: "HomePro", price: 34.99, rating: 3.8, img: "images/table-fan.png", tags: ["new"], desc: "Quiet 3-speed oscillating table fan with a tilt-adjustable head and sturdy base. Keeps rooms cool all summer." },
];

const BRANDS = [...new Set(PRODUCTS.map(p => p.brand))].sort();
const FREE_SHIPPING_OVER = 100;
const SHIPPING_FEE = 5;
const MAX_PRICE = 1000;

/* ---------- Storage helpers (safe) ---------- */
const store = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); }
    catch (e) { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* ignore */ }
  },
};

/* ---------- State ---------- */
const state = {
  cart: store.get("se_cart", []),          // [{id, qty}]
  wish: store.get("se_wish", []),          // [id]
  orders: store.get("se_orders", []),      // [{id, date, items, total}]
  users: store.get("se_users", []),        // [{name, email, password, joined}]
  user: store.get("se_user", null),        // {name, email, joined}
  dark: store.get("se_dark", false),
  detailQty: 1,
  filters: { category: "All", maxPrice: MAX_PRICE, brands: [], minRating: 0, search: "", sort: "default" },
};

/* ---------- Utilities ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const money = n => "$" + (Math.round(n * 100) / 100).toFixed(2);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const byId = id => PRODUCTS.find(p => p.id === Number(id));
const toCents = n => Math.round(n * 100);

function toast(msg, type = "ok") {
  const el = document.createElement("div");
  el.className = "toast" + (type === "error" ? " error" : "");
  el.textContent = msg;
  $("#toastWrap").appendChild(el);
  setTimeout(() => {
    el.classList.add("out");
    el.addEventListener("animationend", () => el.remove());
  }, 2400);
}

function stars(rating) {
  return `<span class="rating"><span class="stars" aria-hidden="true"><span style="width:${(rating / 5) * 100}%"></span></span><span>${rating.toFixed(1)}</span></span>`;
}

const heartSVG = '<svg viewBox="0 0 24 24" width="20" height="20" stroke-linejoin="round"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>';

/* ---------- Product card ---------- */
function cardHTML(p, delay = 0) {
  const wished = state.wish.includes(p.id);
  const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
  return `
  <article class="product-card" style="animation-delay:${delay}ms">
    <div class="pc-img">
      ${discount ? `<span class="pc-badge">-${discount}%</span>` : ""}
      <button class="wish-btn ${wished ? "active" : ""}" data-action="wish" data-id="${p.id}" aria-label="${wished ? "Remove from" : "Add to"} wishlist" aria-pressed="${wished}">${heartSVG}</button>
      <img src="${p.img}" alt="${esc(p.name)}" loading="lazy" data-action="view" data-id="${p.id}">
    </div>
    <div class="pc-body">
      <span class="pc-cat">${esc(p.category)} · ${esc(p.brand)}</span>
      <h3 class="pc-name">${esc(p.name)}</h3>
      ${stars(p.rating)}
      <div class="price">${money(p.price)}${p.oldPrice ? `<del>${money(p.oldPrice)}</del>` : ""}</div>
      <div class="pc-actions">
        <button class="btn" data-action="add" data-id="${p.id}">Add to Cart</button>
        <button class="btn btn-outline" data-action="view" data-id="${p.id}">View Details</button>
      </div>
    </div>
  </article>`;
}

function renderGrid(el, list) {
  el.innerHTML = list.map((p, i) => cardHTML(p, i * 50)).join("");
}

/* ---------- Counters & badges ---------- */
function cartCount() { return state.cart.reduce((n, i) => n + i.qty, 0); }

function updateBadges(bump = false) {
  $("#cartCount").textContent = cartCount();
  $("#wishCount").textContent = state.wish.length;
  if (bump) {
    const icon = $("#cartIcon");
    icon.classList.remove("bump");
    void icon.offsetWidth; // restart animation
    icon.classList.add("bump");
  }
}

function saveAll() {
  store.set("se_cart", state.cart);
  store.set("se_wish", state.wish);
  store.set("se_orders", state.orders);
}

/* ---------- Cart logic ---------- */
function addToCart(id, qty = 1) {
  const item = state.cart.find(i => i.id === id);
  if (item) item.qty = Math.min(99, item.qty + qty);
  else state.cart.push({ id, qty });
  saveAll();
  updateBadges(true);
  toast(`${byId(id).name} added to cart`);
}

function changeQty(id, delta) {
  const item = state.cart.find(i => i.id === id);
  if (!item) return;
  item.qty = Math.min(99, Math.max(1, item.qty + delta));
  saveAll(); updateBadges(); renderCart();
}

function removeFromCart(id) {
  state.cart = state.cart.filter(i => i.id !== id);
  saveAll(); updateBadges(); renderCart();
  toast("Item removed from cart");
}

function cartTotals() {
  const subtotalCents = state.cart.reduce((sum, i) => sum + toCents(byId(i.id).price) * i.qty, 0);
  const shippingCents = subtotalCents === 0 || subtotalCents >= FREE_SHIPPING_OVER * 100 ? 0 : SHIPPING_FEE * 100;
  return { items: cartCount(), subtotal: subtotalCents / 100, shipping: shippingCents / 100, total: (subtotalCents + shippingCents) / 100 };
}

function renderCart() {
  const box = $("#cartItems");
  const summary = $("#cartSummary");
  if (!state.cart.length) {
    box.innerHTML = `<div class="empty"><div class="empty-icon">🛒</div><h3>Your cart is empty</h3><p>Looks like you haven't added anything yet.</p><a href="#/products" class="btn">Start Shopping</a></div>`;
    summary.hidden = true;
    $("#cartSubtitle").textContent = "";
    return;
  }
  summary.hidden = false;
  box.innerHTML = state.cart.map(i => {
    const p = byId(i.id);
    return `
    <div class="cart-row">
      <img src="${p.img}" alt="${esc(p.name)}">
      <div><div class="ci-name">${esc(p.name)}</div><div class="ci-price">${money(p.price)} each</div></div>
      <div class="qty">
        <button data-action="dec" data-id="${p.id}" aria-label="Decrease quantity">−</button>
        <span aria-live="polite">${i.qty}</span>
        <button data-action="inc" data-id="${p.id}" aria-label="Increase quantity">+</button>
      </div>
      <div class="ci-total">${money(p.price * i.qty)}</div>
      <button class="remove-btn" data-action="remove" data-id="${p.id}" aria-label="Remove ${esc(p.name)}">🗑</button>
    </div>`;
  }).join("");
  const t = cartTotals();
  $("#sumItems").textContent = t.items;
  $("#sumSubtotal").textContent = money(t.subtotal);
  $("#sumShipping").textContent = t.shipping === 0 ? "Free" : money(t.shipping);
  $("#sumTotal").textContent = money(t.total);
  $("#cartSubtitle").textContent = `${t.items} item${t.items === 1 ? "" : "s"} in your cart`;
}

function checkout() {
  if (!state.cart.length) return;
  if (!state.user) {
    toast("Please login to place your order", "error");
    location.hash = "#/login";
    return;
  }
  const t = cartTotals();
  state.orders.unshift({
    id: "SE" + Date.now().toString().slice(-7),
    date: new Date().toLocaleString(),
    items: state.cart.map(i => ({ name: byId(i.id).name, qty: i.qty, price: byId(i.id).price })),
    total: t.total,
  });
  state.cart = [];
  saveAll(); updateBadges();
  toast("Order placed successfully! 🎉");
  location.hash = "#/orders";
}

/* ---------- Wishlist ---------- */
function toggleWish(id) {
  const i = state.wish.indexOf(id);
  if (i >= 0) { state.wish.splice(i, 1); toast("Removed from wishlist"); }
  else { state.wish.push(id); toast("Added to wishlist ❤️"); }
  saveAll(); updateBadges();
  const on = state.wish.includes(id);
  $$(`.wish-btn[data-id="${id}"]`).forEach(b => {
    b.classList.toggle("active", on);
    b.setAttribute("aria-pressed", on);
    b.setAttribute("aria-label", (on ? "Remove from" : "Add to") + " wishlist");
  });
  if (currentView() === "wishlist") renderWishlist();
}

function renderWishlist() {
  const list = state.wish.map(byId).filter(Boolean);
  renderGrid($("#wishGrid"), list);
  $("#wishEmpty").hidden = list.length > 0;
  $("#wishSubtitle").textContent = list.length ? `${list.length} saved product${list.length === 1 ? "" : "s"}` : "";
}

/* ---------- Home ---------- */
function renderHome() {
  const pick = tag => PRODUCTS.filter(p => p.tags.includes(tag)).slice(0, 4);
  renderGrid($("#featuredGrid"), pick("featured"));
  renderGrid($("#newGrid"), pick("new"));
  renderGrid($("#bestGrid"), pick("best"));
  renderGrid($("#offerGrid"), pick("offer"));
  $("#homeCategories").innerHTML = categoryCards();
}

function categoryCards() {
  return CATEGORIES.map(c => {
    const n = PRODUCTS.filter(p => p.category === c.name).length;
    return `<a class="category-card" href="#/products?cat=${encodeURIComponent(c.name)}">
      <img src="${c.img}" alt="${c.name}" loading="lazy">
      <div class="cat-overlay"><h3>${c.name}</h3><span>${n} products</span></div>
    </a>`;
  }).join("");
}

/* ---------- Products: sidebar filters, search, sort ---------- */
function buildFilters() {
  const catBox = $("#categoryFilter");
  const cats = ["All", ...CATEGORIES.map(c => c.name)];
  catBox.innerHTML = cats.map(c => {
    const n = c === "All" ? PRODUCTS.length : PRODUCTS.filter(p => p.category === c).length;
    return `<label><input type="radio" name="cat" value="${c}"> ${c} <span class="count">${n}</span></label>`;
  }).join("");

  $("#brandFilter").innerHTML = BRANDS.map(b => {
    const n = PRODUCTS.filter(p => p.brand === b).length;
    return `<label><input type="checkbox" name="brand" value="${b}"> ${b} <span class="count">${n}</span></label>`;
  }).join("");

  const ratings = [[0, "All ratings"], [4, "4★ & up"], [3, "3★ & up"], [2, "2★ & up"]];
  $("#ratingFilter").innerHTML = ratings.map(([v, label]) =>
    `<label><input type="radio" name="rating" value="${v}"> ${label}</label>`).join("");

  catBox.addEventListener("change", e => { state.filters.category = e.target.value; renderProducts(); });
  $("#brandFilter").addEventListener("change", () => {
    state.filters.brands = $$('input[name="brand"]:checked').map(i => i.value);
    renderProducts();
  });
  $("#ratingFilter").addEventListener("change", e => { state.filters.minRating = Number(e.target.value); renderProducts(); });
  $("#priceRange").addEventListener("input", e => { state.filters.maxPrice = Number(e.target.value); renderProducts(); });
  $("#sortSelect").addEventListener("change", e => { state.filters.sort = e.target.value; renderProducts(); });
  $("#resetFilters").addEventListener("click", resetFilters);
  $("#noResultsReset").addEventListener("click", resetFilters);
}

function syncFilterUI() {
  const f = state.filters;
  $$('input[name="cat"]').forEach(i => (i.checked = i.value === f.category));
  $$('input[name="brand"]').forEach(i => (i.checked = f.brands.includes(i.value)));
  $$('input[name="rating"]').forEach(i => (i.checked = Number(i.value) === f.minRating));
  $("#priceRange").value = f.maxPrice;
  $("#sortSelect").value = f.sort;
  $("#searchInput").value = f.search;
}

function resetFilters() {
  state.filters = { category: "All", maxPrice: MAX_PRICE, brands: [], minRating: 0, search: "", sort: "default" };
  syncFilterUI();
  renderProducts();
}

function filteredProducts() {
  const f = state.filters;
  const q = f.search.trim().toLowerCase();
  let list = PRODUCTS.filter(p =>
    (f.category === "All" || p.category === f.category) &&
    p.price <= f.maxPrice &&
    (!f.brands.length || f.brands.includes(p.brand)) &&
    p.rating >= f.minRating &&
    (!q || p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || p.category.toLowerCase().includes(q))
  );
  if (f.sort === "low") list.sort((a, b) => a.price - b.price);
  else if (f.sort === "high") list.sort((a, b) => b.price - a.price);
  else if (f.sort === "rating") list.sort((a, b) => b.rating - a.rating);
  else if (f.sort === "name") list.sort((a, b) => a.name.localeCompare(b.name));
  return list;
}

function renderProducts() {
  const f = state.filters;
  const list = filteredProducts();
  renderGrid($("#productGrid"), list);
  $("#noResults").hidden = list.length > 0;
  $("#priceValue").textContent = f.maxPrice >= MAX_PRICE ? "Any price" : `Up to $${f.maxPrice}`;
  let text = `Showing ${list.length} of ${PRODUCTS.length} products`;
  if (f.search.trim()) text += ` for “${f.search.trim()}”`;
  $("#resultCount").textContent = text;
}

/* ---------- Categories page ---------- */
function renderCategories() { $("#categoryGrid").innerHTML = categoryCards(); }

/* ---------- Product details ---------- */
function renderDetails(id) {
  const p = byId(id);
  if (!p) { toast("Product not found", "error"); location.hash = "#/products"; return false; }
  state.detailQty = 1;
  const wished = state.wish.includes(p.id);
  $("#detailsBox").innerHTML = `
    <div class="details-img"><img src="${p.img}" alt="${esc(p.name)}"></div>
    <div class="details-info">
      <span class="meta">${esc(p.category)} · ${esc(p.brand)}</span>
      <h1>${esc(p.name)}</h1>
      ${stars(p.rating)}
      <div class="price">${money(p.price)}${p.oldPrice ? `<del>${money(p.oldPrice)}</del>` : ""}</div>
      <p class="desc">${esc(p.desc)}</p>
      <div class="qty-row">
        <strong>Quantity</strong>
        <div class="qty">
          <button data-action="ddec" aria-label="Decrease quantity">−</button>
          <span id="detailQty" aria-live="polite">1</span>
          <button data-action="dinc" aria-label="Increase quantity">+</button>
        </div>
      </div>
      <div class="details-actions">
        <button class="btn" data-action="dadd" data-id="${p.id}">Add to Cart</button>
        <button class="btn btn-outline wish-btn-text ${wished ? "active" : ""}" data-action="wish" data-id="${p.id}">♥ Wishlist</button>
      </div>
    </div>`;
  renderGrid($("#relatedGrid"), PRODUCTS.filter(x => x.category === p.category && x.id !== p.id).slice(0, 4));
  document.title = `${p.name} | ShopEase`;
  return true;
}

/* ---------- Orders, profile, settings ---------- */
function renderOrders() {
  const box = $("#ordersList");
  if (!state.orders.length) {
    box.innerHTML = `<div class="empty"><div class="empty-icon">📦</div><h3>No orders yet</h3><p>Your placed orders will appear here.</p><a href="#/products" class="btn">Shop Now</a></div>`;
    return;
  }
  box.innerHTML = state.orders.map(o => `
    <div class="order">
      <div class="order-head"><strong>Order #${o.id}</strong><span>${esc(o.date)}</span></div>
      <ul>${o.items.map(i => `<li><span>${esc(i.name)} × ${i.qty}</span><span>${money(i.price * i.qty)}</span></li>`).join("")}</ul>
      <div class="order-total">Total: ${money(o.total)}</div>
    </div>`).join("");
}

function renderProfile() {
  const u = state.user;
  $("#profileBox").innerHTML = `
    <div class="profile-top">
      <div class="avatar">${esc(u.name.charAt(0).toUpperCase())}</div>
      <div><h2>${esc(u.name)}</h2><p>${esc(u.email)}</p><small>Member since ${esc(u.joined || "today")}</small></div>
    </div>
    <div class="profile-grid">
      <div><strong>${state.orders.length}</strong>Orders</div>
      <div><strong>${state.wish.length}</strong>Wishlist items</div>
      <div><strong>${cartCount()}</strong>Items in cart</div>
    </div>`;
}

function applyTheme() {
  document.body.classList.toggle("dark", !!state.dark);
  $("#darkToggle").checked = !!state.dark;
}

/* ---------- Auth UI ---------- */
function updateAuthUI() {
  const u = state.user;
  const link = $("#navLoginLink");
  if (u) { link.textContent = "Hi, " + u.name.split(" ")[0]; link.setAttribute("href", "#/profile"); link.dataset.nav = "profile"; }
  else { link.textContent = "Login / Signup"; link.setAttribute("href", "#/login"); link.dataset.nav = "login"; }
  $("#drawerName").textContent = u ? u.name : "Guest";
  $("#drawerEmail").textContent = u ? u.email : "Not logged in";
  $("#drawerAvatar").textContent = u ? u.name.charAt(0).toUpperCase() : "G";
}

function logout() {
  if (!state.user) { toast("You are not logged in", "error"); return; }
  state.user = null;
  store.set("se_user", null);
  updateAuthUI();
  toast("You have been logged out");
}

/* ---------- Form validation ---------- */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function setError(input, msg) {
  const field = input.closest(".field");
  field.classList.toggle("invalid", !!msg);
  $(".error", field).textContent = msg || "";
  return !msg;
}
function clearErrors(form) { $$(".field", form).forEach(f => { f.classList.remove("invalid"); $(".error", f).textContent = ""; }); }

function validateEmail(input) {
  const v = input.value.trim();
  if (!v) return setError(input, "Email is required");
  if (!EMAIL_RE.test(v)) return setError(input, "Enter a valid email address");
  return setError(input, "");
}
function validateName(input) {
  const v = input.value.trim();
  if (!v) return setError(input, "Name is required");
  if (v.length < 3) return setError(input, "Name must be at least 3 characters");
  if (!/^[A-Za-z][A-Za-z\s.'-]*$/.test(v)) return setError(input, "Name can only contain letters and spaces");
  return setError(input, "");
}
function validateStrongPass(input) {
  const v = input.value;
  if (!v) return setError(input, "Password is required");
  if (v.length < 6) return setError(input, "Password must be at least 6 characters");
  if (!/[A-Za-z]/.test(v) || !/\d/.test(v)) return setError(input, "Use both letters and numbers");
  return setError(input, "");
}

function showAuthTab(tab) {
  $("#loginForm").hidden = tab !== "login";
  $("#signupForm").hidden = tab !== "signup";
  $("#tabLogin").classList.toggle("active", tab === "login");
  $("#tabSignup").classList.toggle("active", tab === "signup");
}

function initForms() {
  // Tabs
  const showTab = showAuthTab;
  $$(".tab").forEach(t => t.addEventListener("click", () => showTab(t.dataset.tab)));
  $$("[data-switch]").forEach(a => a.addEventListener("click", e => { e.preventDefault(); showTab(a.dataset.switch); }));

  // Login
  const lf = $("#loginForm");
  lf.addEventListener("submit", e => {
    e.preventDefault();
    const email = $("#lEmail"), pass = $("#lPass"), msg = $("#loginMsg");
    msg.textContent = ""; msg.className = "form-msg";
    const okEmail = validateEmail(email);
    const okPass = pass.value ? setError(pass, "") : setError(pass, "Password is required");
    if (!okEmail || !okPass) return;
    const user = state.users.find(u => u.email === email.value.trim().toLowerCase() && u.password === pass.value);
    if (!user) { msg.textContent = "Invalid email or password. Please sign up first if you are new."; msg.classList.add("bad"); return; }
    state.user = { name: user.name, email: user.email, joined: user.joined };
    store.set("se_user", state.user);
    updateAuthUI();
    lf.reset();
    toast(`Welcome back, ${user.name.split(" ")[0]}!`);
    location.hash = "#/home";
  });
  $("#lEmail").addEventListener("blur", e => validateEmail(e.target));

  // Signup
  const sf = $("#signupForm");
  sf.addEventListener("submit", e => {
    e.preventDefault();
    const name = $("#sName"), email = $("#sEmail"), pass = $("#sPass"), conf = $("#sConfirm"), terms = $("#sTerms"), msg = $("#signupMsg");
    msg.textContent = ""; msg.className = "form-msg";
    const checks = [validateName(name), validateEmail(email), validateStrongPass(pass)];
    checks.push(!conf.value ? setError(conf, "Please confirm your password")
      : conf.value !== pass.value ? setError(conf, "Passwords do not match") : setError(conf, ""));
    checks.push(setError(terms, terms.checked ? "" : "You must accept the terms"));
    if (checks.includes(false)) return;
    const mail = email.value.trim().toLowerCase();
    if (state.users.some(u => u.email === mail)) { msg.textContent = "An account with this email already exists."; msg.classList.add("bad"); return; }
    const user = { name: name.value.trim(), email: mail, password: pass.value, joined: new Date().toLocaleDateString() };
    state.users.push(user);
    store.set("se_users", state.users);
    state.user = { name: user.name, email: user.email, joined: user.joined };
    store.set("se_user", state.user);
    updateAuthUI();
    sf.reset();
    toast("Account created. Welcome to ShopEase!");
    location.hash = "#/home";
  });
  $("#sName").addEventListener("blur", e => validateName(e.target));
  $("#sEmail").addEventListener("blur", e => validateEmail(e.target));
  $("#sPass").addEventListener("blur", e => validateStrongPass(e.target));
  $("#sConfirm").addEventListener("blur", e => {
    if (e.target.value && e.target.value !== $("#sPass").value) setError(e.target, "Passwords do not match");
  });

  // Clear error while typing
  $$("#loginForm input, #signupForm input, #contactForm input, #contactForm textarea").forEach(i =>
    i.addEventListener("input", () => { if (i.closest(".field").classList.contains("invalid")) setError(i, ""); }));

  // Contact
  $("#contactForm").addEventListener("submit", e => {
    e.preventDefault();
    const n = $("#cName"), m = $("#cEmail"), t = $("#cMsg");
    const ok = [validateName(n), validateEmail(m),
      t.value.trim().length < 10 ? setError(t, "Message must be at least 10 characters") : setError(t, "")];
    if (ok.includes(false)) return;
    e.target.reset(); clearErrors(e.target);
    toast("Thanks! Your message has been sent.");
  });
}

/* ---------- Navigation drawer ---------- */
const drawer = $("#drawer"), overlay = $("#overlay"), menuBtn = $("#menuBtn");
function openDrawer() {
  drawer.classList.add("open"); overlay.classList.add("show");
  drawer.setAttribute("aria-hidden", "false"); menuBtn.setAttribute("aria-expanded", "true");
  document.body.style.overflow = "hidden";
}
function closeDrawer() {
  drawer.classList.remove("open"); overlay.classList.remove("show");
  drawer.setAttribute("aria-hidden", "true"); menuBtn.setAttribute("aria-expanded", "false");
  document.body.style.overflow = "";
}

/* ---------- Slideshow ---------- */
function initSlideshow() {
  const box = $("#slideshow");
  const slides = $$(".slide", box);
  const dotsBox = $("#slideDots");
  let index = 0, timer = null;
  const DELAY = 4500;

  slides.forEach((_, i) => {
    const d = document.createElement("button");
    d.className = "dot"; d.setAttribute("aria-label", `Go to slide ${i + 1}`);
    d.addEventListener("click", () => { show(i); restart(); });
    dotsBox.appendChild(d);
  });
  const dots = $$(".dot", dotsBox);

  function show(i) {
    index = (i + slides.length) % slides.length;
    slides.forEach((s, n) => s.classList.toggle("active", n === index));
    dots.forEach((d, n) => d.classList.toggle("active", n === index));
  }
  const next = () => show(index + 1);
  const prev = () => show(index - 1);
  function start() { stop(); timer = setInterval(next, DELAY); }
  function stop() { clearInterval(timer); }
  function restart() { start(); }

  $("#slideNext").addEventListener("click", () => { next(); restart(); });
  $("#slidePrev").addEventListener("click", () => { prev(); restart(); });
  box.addEventListener("mouseenter", stop);
  box.addEventListener("mouseleave", start);

  // swipe support on touch devices
  let x0 = null;
  box.addEventListener("touchstart", e => { x0 = e.touches[0].clientX; stop(); }, { passive: true });
  box.addEventListener("touchend", e => {
    if (x0 !== null) {
      const dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 40) (dx < 0 ? next : prev)();
    }
    x0 = null; start();
  });

  show(0); start();
}

/* ---------- Router ---------- */
const VIEWS = ["home", "products", "categories", "details", "cart", "wishlist", "orders", "profile", "settings", "about", "contact", "login"];
const PROTECTED = ["orders", "profile"];
let activeView = "home";
function currentView() { return activeView; }

function router() {
  const raw = (location.hash || "#/home").replace(/^#\/?/, "");
  const [path, query = ""] = raw.split("?");
  const [segment, param] = path.split("/");
  let name = segment === "product" ? "details" : segment || "home";

  if (name === "logout") { logout(); location.replace("#/home"); return; }
  if (!VIEWS.includes(name)) name = "home";
  if (PROTECTED.includes(name) && !state.user) {
    toast("Please login to continue", "error");
    location.replace("#/login");
    return;
  }

  closeDrawer();
  if (name === "details" && !renderDetails(param)) return;
  if (name !== "details") document.title = "ShopEase | Online Shopping Website";

  if (name === "products") {
    const params = new URLSearchParams(query);
    if (params.has("cat")) {
      state.filters = { category: params.get("cat"), maxPrice: MAX_PRICE, brands: [], minRating: 0, search: "", sort: "default" };
    }
    syncFilterUI();
    renderProducts();
  }
  if (name === "home") renderHome();
  if (name === "categories") renderCategories();
  if (name === "cart") renderCart();
  if (name === "wishlist") renderWishlist();
  if (name === "orders") renderOrders();
  if (name === "profile") renderProfile();
  if (name === "login") { showAuthTab("login"); clearErrors($("#loginForm")); clearErrors($("#signupForm")); }

  activeView = name;
  VIEWS.forEach(v => { $("#view-" + v).hidden = v !== name; });
  $$(".main-nav a").forEach(a => {
    const key = a.dataset.nav;
    a.classList.toggle("active", key === name || (name === "details" && key === "products"));
  });
  $("#sidebar").classList.remove("open");
  $("#filterToggle").setAttribute("aria-expanded", "false");
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
}

/* ---------- Global events ---------- */
document.addEventListener("click", e => {
  const t = e.target.closest("[data-action]");
  if (!t) return;
  const id = Number(t.dataset.id);
  switch (t.dataset.action) {
    case "add": addToCart(id); break;
    case "view": location.hash = "#/product/" + id; break;
    case "wish": toggleWish(id); break;
    case "inc": changeQty(id, 1); break;
    case "dec": changeQty(id, -1); break;
    case "remove": removeFromCart(id); break;
    case "dinc": state.detailQty = Math.min(99, state.detailQty + 1); $("#detailQty").textContent = state.detailQty; break;
    case "ddec": state.detailQty = Math.max(1, state.detailQty - 1); $("#detailQty").textContent = state.detailQty; break;
    case "dadd": addToCart(id, state.detailQty); break;
  }
});

menuBtn.addEventListener("click", openDrawer);
$("#drawerClose").addEventListener("click", closeDrawer);
overlay.addEventListener("click", closeDrawer);
document.addEventListener("keydown", e => { if (e.key === "Escape") closeDrawer(); });
// Clicking a drawer link to the page we are already on must still close the drawer
drawer.addEventListener("click", e => { if (e.target.closest("a")) closeDrawer(); });

$("#searchForm").addEventListener("submit", e => {
  e.preventDefault();
  state.filters = { category: "All", maxPrice: MAX_PRICE, brands: [], minRating: 0, search: $("#searchInput").value, sort: "default" };
  if (location.hash.startsWith("#/products")) { if (location.hash !== "#/products") location.hash = "#/products"; else router(); }
  else location.hash = "#/products";
  syncFilterUI();
  renderProducts();
});
// live search while typing on the products page
$("#searchInput").addEventListener("input", e => {
  state.filters.search = e.target.value;
  if (currentView() === "products") renderProducts();
});

$("#filterToggle").addEventListener("click", () => {
  const open = $("#sidebar").classList.toggle("open");
  $("#filterToggle").setAttribute("aria-expanded", open);
});

$("#checkoutBtn").addEventListener("click", checkout);
$("#clearCart").addEventListener("click", () => {
  state.cart = []; saveAll(); updateBadges(); renderCart(); toast("Cart cleared");
});

$("#darkToggle").addEventListener("change", e => { state.dark = e.target.checked; store.set("se_dark", state.dark); applyTheme(); });
$("#clearWish").addEventListener("click", () => { state.wish = []; saveAll(); updateBadges(); toast("Wishlist cleared"); });
$("#clearOrders").addEventListener("click", () => { state.orders = []; saveAll(); toast("Order history cleared"); });

window.addEventListener("hashchange", router);

/* ---------- Init ---------- */
buildFilters();
initForms();
initSlideshow();
applyTheme();
updateAuthUI();
updateBadges();
router();
